<?php
	$translate['Optionnal'] = 'Optionnel';
	$translate['Transfered by AdminServ'] = 'Transferé par AdminServ';
	$translate['Confirmation of the transfer by AdminServ'] = 'Confirmation de transfert par AdminServ';
	$translate['Transaction'] = 'Transaction';
	$translate['No transfer made.'] = 'Aucun transfert effectué.';
	$translate['Infos'] = 'Infos';
	$translate['Number of planets:'] = 'Nombre de planets :';
	$translate['Transfer state:'] = 'Statut du transfert :';
	$translate['Transfers'] = 'Transferts';
	$translate['Amount'] = 'Somme';
	$translate['Confirmation from a player on the server is necessary.'] = 'Nécessite une confirmation du joueur sur le serveur.';
	$translate['Transfer'] = 'Transférer';
?>