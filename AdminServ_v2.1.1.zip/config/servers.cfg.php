<?php
class ServerConfig {
    public static $SERVERS = array(
        /********************* SERVER CONFIGURATION *********************/

        /*
        'new server name' => array(
            'address'		=> 'localhost',
            'port'			=> 5000,
            'mapsbasepath'	=> '',
            'matchsettings'	=> 'MatchSettings/',
            'adminlevel'	=> array('SuperAdmin' => 'all', 'Admin' => 'all', 'User' => 'all'),
            'ds_pw'         => 'User'
        ),
        */
    );
}
?>